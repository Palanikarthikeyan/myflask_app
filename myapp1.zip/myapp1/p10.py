from flask import * #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/")
def index():
	return "<h1><font color=green>Welcome to flask app</font></h1>"

@app.route("/emp_display",methods=['POST']) # <==  (3)
def f1():
	en=request.form['n1']
	ed=request.form['n2']
	return render_template('emp_display.html',temp_n=en,temp_d=ed)

if __name__ == '__main__':
	app.run(debug=True) #<==(5)