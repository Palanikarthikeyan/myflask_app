from flask import *

app = Flask(__name__)

students=[
{'regno':101,'name':'Arun','dept':'physics'},
{'regno':102,'name':'leo','dept':'Maths'},
{'regno':103,'name':'anu','dept':'CS'},
{'regno':104,'name':'bibu','dept':'Civil'},]


@app.route("/")
def index():
	return '<h1>About student details</h1>'

@app.route('/api/v1/resource/students/all')
def api_call():
	return jsonify(students)

if __name__ == '__main__':
	app.run(debug=True)

