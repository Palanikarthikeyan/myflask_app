from flask import * #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/") # <==  (3)
def f1(): #<== (4)
	return "<h1><font color='green'>Welcome to Flask App</font></h1>"

@app.route("/result")
def f2():
	L=['Server1','Server2','Server3']
	T=('DB1','DB2','DB3')
	d={'host01':'host1server','host02':'host2server'}
	return render_template('repo.html',Temp_L=L,Temp_T=T,Temp_d=d)

if __name__ == '__main__':
	app.run(debug=True) #<==(5)