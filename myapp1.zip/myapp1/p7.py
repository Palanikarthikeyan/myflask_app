from flask import * #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/") # <==  (3)
def f1(): #<== (4)
	return "<h1><font color='green'>Welcome to Flask App</font></h1>"

@app.route("/page/<pname>")
def f2(pname):
	return render_template("dis.html",temp_var=pname,n=45,cost=1234.34,servers=None)

@app.route("/display")
def f3():
	return render_template("dis.html",n=0,cost=0.0,servers=["Linux","Unix"])

@app.route("/myenv")
def f4():
	sysinfo={"shell":"/bin/bash","kernel":"Linux"}
	return render_template("view.html",temp_var=sysinfo)

if __name__ == '__main__':
	app.run(debug=True) #<==(5)