from flask import Flask #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/") # <==  (3)
def f1(): #<== (4)
	return "<h1><font color='green'>Welcome to Flask App</font></h1>"

@app.route("/home")
def f2():
	return "<h2>This is my Home page</h2>"

if __name__ == '__main__':
	app.run(debug=True) #<==(5)