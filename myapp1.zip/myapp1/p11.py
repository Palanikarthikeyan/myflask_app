import sqlite3

dbh=sqlite3.connect("emp.db")
sth=dbh.cursor()
sth.execute("create table Emp_table1(eid INT,ename TEXT,edept TEXT)")
sth.execute("insert into Emp_table1 values('101','Leo','sales')")
sth.execute("insert into Emp_table1 values('102','Paul','HR')")

e_id=input("Enter an emp id:")
e_name=input("Enter an emp name:")
e_dept=input("Enter an emp dept:")

sth.execute("insert into Emp_table1 values(?,?,?)",(e_id,e_name,e_dept))

sth.execute("select *from Emp_table1")
print("Get list of records:-")

for v1,v2,v3 in sth:
	print("{}\t{}\t{}".format(v1,v2,v3))


dbh.close()

