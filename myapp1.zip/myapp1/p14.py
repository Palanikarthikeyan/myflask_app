from flask import *

app=Flask(__name__)

d={'env':'env details','os':['winx','Linux']} 

@app.route("/")
def f1():
	return "<h1> about this web app </h1>"


@app.route("/api/v1/resource")
def f2():
	return jsonify(d)
	       ############# flask.jsonify(python_struct)

if __name__ == '__main__':
	app.run(debug=True)