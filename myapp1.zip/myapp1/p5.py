from flask import * #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/") # <==  (3)
def f1(): #<== (4)
	return "<h1><font color='green'>Welcome to Flask App</font></h1>"

@app.route("/page")
def f2():
	return render_template("gpage.html")

@app.route("/docs")
def f3():
	return render_template("python_page.html")

@app.route("/display")
def f4():
	return render_template("dis.html")

@app.route("/mypage/<ip_var>")
def f5(ip_var):
	if ip_var == "page":
		return redirect(url_for('f2'))
	elif ip_var == "docs":
		return redirect(url_for('f3'))
	else:
		return redirect(url_for('f4'))


if __name__ == '__main__':
	app.run(debug=True) #<==(5)