from flask import * #<==(1)

app=Flask(__name__) # constructor  <==(2)

@app.route("/") # <==  (3)
def f1(): #<== (4)
	return "<h1><font color='green'>Welcome to Flask App</font></h1>"

@app.route("/home")
def f2():
	return "<h2>This is my Home page</h2>"

@app.route("/dept/<v>")
def f3(v):
	return "<h2>input dept is:{}</h2>".format(v)

@app.route("/mypage")
def f4():
	return redirect(url_for('f3',v='CRM'))

@app.route("/mydata/<ip_var>")
def f5(ip_var):
	if ip_var == "codeA":
		return redirect(url_for('f3',v='CRM'))
	elif ip_var == "codeB":
		return redirect(url_for('f2'))
	else:
		return redirect(url_for('f1'))


if __name__ == '__main__':
	app.run(debug=True) #<==(5)