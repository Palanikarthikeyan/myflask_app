import requests
import json
import pprint

r=requests.get('https://www.google.com')
if r.status_code != 200:
    print("Page download is failed")
    exit()

page=r.text

r=requests.get('https://api.github.com/users/hadley/orgs')
if r.status_code != 200:
    print("download is failed")
    exit()

jd=r.text

pd=json.loads(jd) # from json to python
print(type(pd),len(pd))
print(type(pd[0]))

pprint.pprint(pd)
