from flask import *

app = Flask(__name__)

students=[
{'regno':101,'name':'Arun','dept':'physics'},
{'regno':102,'name':'leo','dept':'Maths'},
{'regno':103,'name':'anu','dept':'CS'},
{'regno':104,'name':'bibu','dept':'Civil'},]


@app.route("/")
def index():
	return '<h1>About student details</h1>'

@app.route('/api/v1/resource/students/all')
def api_call():
	return jsonify(students)

@app.route('/api/v1/resource/students',methods=['GET'])
def api_call_regno():
	if 'regno' in request.args:
		rv=int(request.args['regno'])
	else:
		return "<h2><font color=red>Error: There is no regno is provided</font></h2>"
	r=[]
	for var in students:
		if var['regno'] == rv:
			r.append(rv)
	return jsonify(r)

if __name__ == '__main__':
	app.run(debug=True)

