from flask import *
import json #<===
app=Flask(__name__)

d={'env':'env details','os':['winx','Linux']} #<==
jd=json.dumps(d) #<==

@app.route("/")
def f1():
	return "<h1> about this web app </h1>"


@app.route("/api/v1/resource")
def f2():
	return jd
	       #-----//this is not html (webpage)

if __name__ == '__main__':
	app.run(debug=True)